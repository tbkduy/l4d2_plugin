# [L4D2] Assist Revive

Plugin SourceMod mô phỏng mod Workshop "No One Left Behind": người thứ hai giữ **E** để hỗ trợ đồng đội đang hồi sinh một người bị gục. Thời gian còn lại được rút ngắn một nửa.

## Cài đặt
1. Cài **SourceMod 1.11+** và **[Left 4 DHooks Direct](https://forums.alliedmods.net/showthread.php?t=321696)** (Silvers).
2. Biên dịch `scripting/l4d2_assist_revive.sp` bằng `spcomp` (cần `left4dhooks.inc` trong thư mục `include`), rồi chép file `.smx` vào `addons/sourcemod/plugins/`.
3. Chép `translations/l4d2_assist_revive.phrases.txt` vào **đúng** `addons/sourcemod/translations/` (không đặt trong `translations/custom/` hay thư mục con). Nếu thiếu file này, plugin vẫn chạy và dùng thông báo tiếng Việt dựng sẵn.
4. Đổi map hoặc `sm plugins load l4d2_assist_revive`. File cấu hình được tạo tự động tại `cfg/sourcemod/l4d2_assist_revive.cfg`.

## Cách chơi
1. Một survivor bị gục (hoặc treo mép).
2. Người thứ nhất cứu như bình thường.
3. Người thứ hai đứng gần, nhìn về phía người bị gục rồi **giữ E**: từ lúc đó phần thời gian còn lại giảm một nửa.
4. Nhả E thì hồi sinh tiếp tục ở tốc độ thường. Người cứu chính bị ngắt thì hủy cho cả hai.

## Giống bản gốc
- Mỗi người bị gục chỉ có 1 người hỗ trợ.
- Adrenaline chỉ tăng tốc người cứu chính, không tăng tốc người hỗ trợ.
- Bot có thể tự đi tới hỗ trợ (dùng `CommandABot`). Bot không hỗ trợ khi có Tank ở gần, và bỏ hỗ trợ khi đứng trong lửa hoặc axit Spitter.

## Khác bản gốc
- **Không dùng bot ẩn**, nên không chiếm slot người chơi và không giới hạn số lượt hỗ trợ cùng lúc.
- Bot thêm vào giữa trận vẫn hoạt động bình thường.
- Có ConVar để chỉnh mọi thông số.

## ConVar
| ConVar | Mặc định | Ý nghĩa |
|---|---|---|
| `l4d2_assist_revive_enable` | 1 | Bật/tắt plugin |
| `l4d2_assist_revive_range` | 110 | Khoảng cách tối đa từ người hỗ trợ tới người bị gục |
| `l4d2_assist_revive_rate` | 1.0 | Tốc độ người hỗ trợ so với người cứu thường (1.0 = còn ½ thời gian, 2.0 = còn ⅓) |
| `l4d2_assist_revive_ledge` | 1 | Cho hỗ trợ kéo người treo mép |
| `l4d2_assist_revive_lock` | 1 | Khóa di chuyển/bắn của người hỗ trợ |
| `l4d2_assist_revive_bots` | 1 | Cho bot tự hỗ trợ |
| `l4d2_assist_revive_bot_delay` | 0.75 | Bot chờ bao lâu rồi mới tới hỗ trợ |
| `l4d2_assist_revive_bot_seek` | 500 | Bán kính bot được lệnh đi tới hỗ trợ (0 = chỉ bot đứng sẵn gần) |
| `l4d2_assist_revive_tank_range` | 900 | Bot không hỗ trợ nếu có Tank trong bán kính này (0 = bỏ qua) |
| `l4d2_assist_revive_notify` | 1 | Hiện thông báo hint |
| `l4d2_assist_revive_thirdperson` | 1 | Người hỗ trợ vào góc nhìn thứ ba giống người cứu chính |
| `l4d2_assist_revive_anim` | 1 | Người hỗ trợ chạy animation hồi sinh (copy từ người cứu chính) và quay mặt về người bị gục |

## Cơ chế kỹ thuật
- Plugin theo dõi `revive_begin`/`revive_end`/`revive_success`, tính tiến độ theo tốc độ (người cứu chính = 1, người hỗ trợ = `rate`, đã quy đổi theo adrenaline).
- Thanh tiến trình (`m_flProgressBarStartTime`/`Duration`) của người cứu, người bị gục và người hỗ trợ được chỉnh lại để hiển thị đúng.
- Khi hết thời gian rút ngắn, plugin gọi `L4D_ReviveSurvivor()` để hoàn tất hồi sinh (số lần gục, máu tạm, trạng thái trắng đen do game tự xử lý).

## Lịch sử
- **1.1.0**: Người hỗ trợ vào góc nhìn thứ ba và chạy animation y hệt người cứu chính (quay mặt về người bị gục). Không còn lỗi "Language phrase not found" khi thiếu file phrase.
- **1.0.0**: Bản đầu tiên.
