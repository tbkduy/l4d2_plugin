/**
 * [L4D2] Assist Revive - "Không bỏ lại ai"
 *
 * Cho phép một survivor thứ hai giữ phím E (+use) để hỗ trợ đồng đội đang
 * hồi sinh một người bị gục. Khi có người hỗ trợ, phần thời gian còn lại
 * được rút ngắn (mặc định: nhanh gấp đôi = còn một nửa).
 *
 *  - Chỉ 1 người hỗ trợ cho mỗi người bị gục.
 *  - Người hỗ trợ nhả E  -> hồi sinh tiếp tục với tốc độ bình thường.
 *  - Người cứu chính bị ngắt -> hủy cho cả hai (do game tự xử lý).
 *  - Adrenaline chỉ tăng tốc người cứu chính, không tăng tốc người hỗ trợ.
 *  - Người hỗ trợ vào góc nhìn thứ ba và dùng animation hồi sinh giống
 *    hệt người cứu chính.
 *  - Bot có thể tự tới hỗ trợ; bot không hỗ trợ khi có Tank ở gần và
 *    sẽ bỏ hỗ trợ nếu đứng trong lửa hoặc axit Spitter.
 *
 * Khác bản mod VScript gốc: không dùng bot ẩn nên không chiếm slot người chơi.
 *
 * Yêu cầu: SourceMod 1.11+, Left 4 DHooks Direct (Silvers).
 */

#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdktools>
#include <sdkhooks>
#include <left4dhooks>

#define PLUGIN_VERSION   "1.1.0"
#define TEAM_SURVIVOR    2
#define TEAM_INFECTED    3
#define ZC_TANK          8
#define INIT_GRACE       0.3   // giây chờ game set thanh tiến trình sau revive_begin

public Plugin myinfo =
{
	name        = "[L4D2] Assist Revive",
	author      = "Claude",
	description = "Người thứ hai giữ E để hỗ trợ hồi sinh, rút ngắn thời gian còn lại",
	version     = PLUGIN_VERSION,
	url         = ""
};

// ---------------------------------------------------------------------------
// ConVars
// ---------------------------------------------------------------------------
ConVar g_cvEnable;
ConVar g_cvRange;
ConVar g_cvHelperRate;
ConVar g_cvLedge;
ConVar g_cvLockHelper;
ConVar g_cvBots;
ConVar g_cvBotDelay;
ConVar g_cvBotSeekRange;
ConVar g_cvTankRange;
ConVar g_cvNotify;
ConVar g_cvThirdPerson;
ConVar g_cvAnim;
ConVar g_cvReviveDuration;   // survivor_revive_duration của game

// ---------------------------------------------------------------------------
// Trạng thái hồi sinh, đánh chỉ số theo client của người bị gục
// ---------------------------------------------------------------------------
enum struct ReviveState
{
	bool  active;
	bool  init;
	bool  boosted;      // đã từng có người hỗ trợ -> plugin chịu trách nhiệm kết thúc
	int   reviver;      // userid người cứu chính
	int   helper;       // client index người hỗ trợ (0 = không có)
	int   seekBot;      // client index bot đang được lệnh di chuyển tới (0 = không)
	float seekUntil;
	float beginTime;
	float total;        // tổng thời lượng thanh tiến trình của người cứu chính
	float remain;       // số "giây của người cứu chính" còn lại
	float helperRate;   // tốc độ người hỗ trợ quy đổi theo người cứu chính
	float last;         // lần cập nhật gần nhất
	float botJoinAt;

	void Reset()
	{
		this.active = false;
		this.init = false;
		this.boosted = false;
		this.reviver = 0;
		this.helper = 0;
		this.seekBot = 0;
		this.seekUntil = 0.0;
		this.beginTime = 0.0;
		this.total = 0.0;
		this.remain = 0.0;
		this.helperRate = 1.0;
		this.last = 0.0;
		this.botJoinAt = 0.0;
	}
}

ReviveState g_State[MAXPLAYERS + 1];
int   g_iHelping[MAXPLAYERS + 1];      // helper -> victim đang được hỗ trợ
int   g_iSeeking[MAXPLAYERS + 1];      // bot -> victim mà bot đang đi tới
bool  g_bUseHeld[MAXPLAYERS + 1];
float g_fBotCooldown[MAXPLAYERS + 1];

// Hiển thị: góc nhìn thứ ba + animation
bool  g_bPhrases;
bool  g_bHasExtView;
bool  g_bExtView[MAXPLAYERS + 1];
bool  g_bHelperHooked[MAXPLAYERS + 1];
bool  g_bReviverHooked[MAXPLAYERS + 1];
int   g_iReviverAct[MAXPLAYERS + 1];     // activity đang chạy của người cứu chính
float g_fHelpYaw[MAXPLAYERS + 1];        // hướng quay mặt về phía người bị gục

// ---------------------------------------------------------------------------
// Khởi tạo
// ---------------------------------------------------------------------------
public APLRes AskPluginLoad2(Handle myself, bool late, char[] error, int err_max)
{
	if (GetEngineVersion() != Engine_Left4Dead2)
	{
		strcopy(error, err_max, "Plugin này chỉ dành cho Left 4 Dead 2.");
		return APLRes_SilentFailure;
	}
	return APLRes_Success;
}

public void OnPluginStart()
{
	// Không crash nếu thiếu file phrase: dùng thông báo tiếng Việt dựng sẵn
	char path[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, path, sizeof(path), "translations/l4d2_assist_revive.phrases.txt");
	g_bPhrases = FileExists(path);
	if (g_bPhrases)
		LoadTranslations("l4d2_assist_revive.phrases");
	else
		LogError("Không tìm thấy \"%s\" - dùng thông báo mặc định.", path);

	g_bHasExtView = FindSendPropInfo("CTerrorPlayer", "m_TimeForceExternalView") > 0;
	if (!g_bHasExtView)
		LogError("Không tìm thấy netprop m_TimeForceExternalView - tắt góc nhìn thứ ba cho người hỗ trợ.");

	CreateConVar("l4d2_assist_revive_version", PLUGIN_VERSION, "Phiên bản plugin", FCVAR_NOTIFY | FCVAR_DONTRECORD);

	g_cvEnable       = CreateConVar("l4d2_assist_revive_enable", "1", "Bật/tắt plugin.", _, true, 0.0, true, 1.0);
	g_cvRange        = CreateConVar("l4d2_assist_revive_range", "110.0", "Khoảng cách tối đa (unit) từ người hỗ trợ tới người bị gục.", _, true, 32.0);
	g_cvHelperRate   = CreateConVar("l4d2_assist_revive_rate", "1.0", "Tốc độ của người hỗ trợ so với một người cứu bình thường. 1.0 = thời gian còn lại giảm một nửa.", _, true, 0.1, true, 10.0);
	g_cvLedge        = CreateConVar("l4d2_assist_revive_ledge", "1", "Cho phép hỗ trợ kéo người đang treo mép.", _, true, 0.0, true, 1.0);
	g_cvLockHelper   = CreateConVar("l4d2_assist_revive_lock", "1", "Khóa di chuyển/bắn của người hỗ trợ (giống khi đang cứu).", _, true, 0.0, true, 1.0);
	g_cvBots         = CreateConVar("l4d2_assist_revive_bots", "1", "Cho phép bot survivor tự hỗ trợ.", _, true, 0.0, true, 1.0);
	g_cvBotDelay     = CreateConVar("l4d2_assist_revive_bot_delay", "0.75", "Bot chờ bao lâu (giây) sau khi bắt đầu cứu mới tới hỗ trợ.", _, true, 0.0);
	g_cvBotSeekRange = CreateConVar("l4d2_assist_revive_bot_seek", "500.0", "Bot trong bán kính này sẽ được lệnh đi tới hỗ trợ. 0 = chỉ bot đã đứng sẵn gần đó.", _, true, 0.0);
	g_cvTankRange    = CreateConVar("l4d2_assist_revive_tank_range", "900.0", "Bot không hỗ trợ nếu có Tank trong bán kính này. 0 = bỏ qua.", _, true, 0.0);
	g_cvNotify       = CreateConVar("l4d2_assist_revive_notify", "1", "Hiện thông báo hint cho những người liên quan.", _, true, 0.0, true, 1.0);
	g_cvThirdPerson  = CreateConVar("l4d2_assist_revive_thirdperson", "1", "Đưa người hỗ trợ vào góc nhìn thứ ba giống người cứu chính.", _, true, 0.0, true, 1.0);
	g_cvAnim         = CreateConVar("l4d2_assist_revive_anim", "1", "Cho người hỗ trợ chạy animation hồi sinh và quay mặt về người bị gục.", _, true, 0.0, true, 1.0);

	AutoExecConfig(true, "l4d2_assist_revive");

	g_cvReviveDuration = FindConVar("survivor_revive_duration");

	HookEvent("revive_begin",   Event_ReviveBegin);
	HookEvent("revive_end",     Event_ReviveStop);
	HookEvent("revive_success", Event_ReviveStop);
	HookEvent("player_death",   Event_PlayerDeath);
	HookEvent("round_start",    Event_RoundStart, EventHookMode_PostNoCopy);

	// Hỗ trợ nạp plugin giữa trận
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i))
			OnClientPutInServer(i);
	}
}

public void OnMapStart()
{
	// Left4DHooks tự gỡ animation hook khi đổi map, chỉ cần reset cờ
	ResetAll();
}

public void OnPluginEnd()
{
	RestoreAllVisuals();
}

void RestoreAllVisuals()
{
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i))
		{
			StopHelperVisuals(i);
			UnhookReviver(i);
		}
	}
}

public void OnClientPutInServer(int client)
{
	SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage);
}

public void OnClientDisconnect(int client)
{
	StopHelperVisuals(client);
	UnhookReviver(client);

	if (g_iHelping[client])
		StopHelper(g_iHelping[client], true);

	if (g_iSeeking[client])
		StopSeek(g_iSeeking[client], false);

	if (g_State[client].active)
		ClearState(client);

	g_bUseHeld[client] = false;
	g_fBotCooldown[client] = 0.0;
}

void ResetAll()
{
	for (int i = 0; i <= MaxClients; i++)
	{
		g_State[i].Reset();
		g_iHelping[i] = 0;
		g_iSeeking[i] = 0;
		g_bUseHeld[i] = false;
		g_fBotCooldown[i] = 0.0;
		g_bExtView[i] = false;
		g_bHelperHooked[i] = false;
		g_bReviverHooked[i] = false;
		g_iReviverAct[i] = 0;
		g_fHelpYaw[i] = 0.0;
	}
}

// ---------------------------------------------------------------------------
// Sự kiện
// ---------------------------------------------------------------------------
void Event_RoundStart(Event event, const char[] name, bool dontBroadcast)
{
	RestoreAllVisuals();
	ResetAll();
}

void Event_ReviveBegin(Event event, const char[] name, bool dontBroadcast)
{
	if (!g_cvEnable.BoolValue)
		return;

	int reviver = GetClientOfUserId(event.GetInt("userid"));
	int victim  = GetClientOfUserId(event.GetInt("subject"));
	if (!IsSurvivor(reviver) || !IsSurvivor(victim))
		return;

	if (!g_cvLedge.BoolValue && GetEntProp(victim, Prop_Send, "m_isHangingFromLedge") != 0)
		return;

	// Người vừa bắt đầu cứu thì thôi hỗ trợ / thôi đi tới chỗ khác
	if (g_iHelping[reviver])
		StopHelper(g_iHelping[reviver], true);
	if (g_iSeeking[reviver])
		StopSeek(g_iSeeking[reviver], false);

	if (g_State[victim].active)
		ClearState(victim);

	float now = GetGameTime();
	g_State[victim].Reset();
	g_State[victim].active    = true;
	g_State[victim].reviver   = GetClientUserId(reviver);
	g_State[victim].beginTime = now;
	g_State[victim].last      = now;

	// Ghi lại animation của người cứu chính để người hỗ trợ chạy y hệt
	if (g_cvAnim.BoolValue && !g_bReviverHooked[reviver])
	{
		g_iReviverAct[reviver] = 0;
		g_bReviverHooked[reviver] = AnimHookEnable(reviver, OnReviverAnim);
	}
}

void Event_ReviveStop(Event event, const char[] name, bool dontBroadcast)
{
	int victim = GetClientOfUserId(event.GetInt("subject"));
	if (victim > 0 && g_State[victim].active)
		ClearState(victim);
}

void Event_PlayerDeath(Event event, const char[] name, bool dontBroadcast)
{
	int client = GetClientOfUserId(event.GetInt("userid"));
	if (client <= 0 || client > MaxClients)
		return;

	if (g_iHelping[client])
		StopHelper(g_iHelping[client], true);
	if (g_iSeeking[client])
		StopSeek(g_iSeeking[client], false);
	if (g_State[client].active)
		ClearState(client);
}

// Bot đứng trong lửa / axit Spitter thì bỏ hỗ trợ
Action OnTakeDamage(int victim, int &attacker, int &inflictor, float &damage, int &damagetype)
{
	if (victim < 1 || victim > MaxClients || !IsFakeClient(victim))
		return Plugin_Continue;

	if (!g_iHelping[victim] && !g_iSeeking[victim])
		return Plugin_Continue;

	bool hazard = (damagetype & DMG_BURN) != 0;
	if (!hazard && inflictor > MaxClients && IsValidEdict(inflictor))
	{
		char cls[32];
		GetEdictClassname(inflictor, cls, sizeof(cls));
		hazard = StrEqual(cls, "insect_swarm") || StrEqual(cls, "inferno") || StrEqual(cls, "fire_cracker_blast");
	}

	if (hazard)
	{
		g_fBotCooldown[victim] = GetGameTime() + 3.0;
		if (g_iHelping[victim])
			StopHelper(g_iHelping[victim], true);
		if (g_iSeeking[victim])
			StopSeek(g_iSeeking[victim], true);
	}
	return Plugin_Continue;
}

// ---------------------------------------------------------------------------
// Input: ghi nhận phím E, khóa người hỗ trợ
// ---------------------------------------------------------------------------
public Action OnPlayerRunCmd(int client, int &buttons, int &impulse, float vel[3], float angles[3], int &weapon,
	int &subtype, int &cmdnum, int &tickcount, int &seed, int mouse[2])
{
	g_bUseHeld[client] = (buttons & IN_USE) != 0;

	if (g_iHelping[client] && g_cvLockHelper.BoolValue)
	{
		vel[0] = 0.0;
		vel[1] = 0.0;
		vel[2] = 0.0;
		buttons &= ~(IN_ATTACK | IN_ATTACK2 | IN_JUMP | IN_RELOAD | IN_FORWARD | IN_BACK | IN_MOVELEFT | IN_MOVERIGHT);
		// Giữ thân người quay về phía người bị gục; camera thứ ba vẫn xoay tự do
		if (g_cvAnim.BoolValue)
			angles[1] = g_fHelpYaw[client];
		return Plugin_Changed;
	}
	return Plugin_Continue;
}

// ---------------------------------------------------------------------------
// Vòng lặp chính
// ---------------------------------------------------------------------------
public void OnGameFrame()
{
	float now = GetGameTime();
	for (int victim = 1; victim <= MaxClients; victim++)
	{
		if (g_State[victim].active)
			ProcessVictim(victim, now);
	}
}

void ProcessVictim(int victim, float now)
{
	int reviver = GetClientOfUserId(g_State[victim].reviver);

	if (!IsDownedSurvivor(victim) || !IsSurvivor(reviver) || !IsPlayerAlive(reviver))
	{
		ClearState(victim);
		return;
	}

	// Sau thời gian chờ, người cứu chính phải thực sự đang cứu nạn nhân này
	if (now - g_State[victim].beginTime > INIT_GRACE
		&& GetEntPropEnt(reviver, Prop_Send, "m_reviveTarget") != victim)
	{
		ClearState(victim);
		return;
	}

	// --- Khởi tạo từ thanh tiến trình thực tế của người cứu chính ---
	if (!g_State[victim].init)
	{
		float dur   = GetEntPropFloat(reviver, Prop_Send, "m_flProgressBarDuration");
		float start = GetEntPropFloat(reviver, Prop_Send, "m_flProgressBarStartTime");

		if (dur <= 0.0)
		{
			if (now - g_State[victim].beginTime < INIT_GRACE)
				return;
			// Dự phòng: dùng cvar của game
			dur   = g_cvReviveDuration != null ? g_cvReviveDuration.FloatValue : 5.0;
			start = g_State[victim].beginTime;
		}

		float base = g_cvReviveDuration != null ? g_cvReviveDuration.FloatValue : dur;
		if (base <= 0.0)
			base = dur;

		g_State[victim].total = dur;
		g_State[victim].remain = dur - (now - start);
		g_State[victim].last = now;
		// Người hỗ trợ làm với tốc độ "bình thường" (không adrenaline).
		// Nếu người cứu chính có adrenaline (dur = base/2) thì người hỗ trợ
		// chỉ đóng góp 0.5 "giây của người cứu chính" mỗi giây.
		g_State[victim].helperRate = (dur / base) * g_cvHelperRate.FloatValue;
		g_State[victim].init = true;
		g_State[victim].botJoinAt = now + g_cvBotDelay.FloatValue;
	}

	// --- Tiến độ trong khung hình vừa qua ---
	int helper = g_State[victim].helper;
	float rate = 1.0 + (helper > 0 ? g_State[victim].helperRate : 0.0);
	g_State[victim].remain -= (now - g_State[victim].last) * rate;
	g_State[victim].last = now;

	// --- Người hỗ trợ còn hợp lệ không? ---
	if (helper && !CanHelp(helper, victim, reviver, true))
	{
		StopHelper(victim, true);
		helper = 0;
	}

	// --- Tìm người hỗ trợ mới ---
	if (!helper && g_cvEnable.BoolValue && g_State[victim].remain > 0.25)
	{
		int candidate = FindHumanHelper(victim, reviver);
		if (!candidate && g_cvBots.BoolValue && now >= g_State[victim].botJoinAt)
			candidate = HandleBots(victim, reviver, now);

		if (candidate)
			StartHelper(victim, candidate, reviver, now);
	}

	// --- Hoàn tất: chỉ can thiệp nếu thời gian đã bị rút ngắn ---
	if (g_State[victim].boosted && g_State[victim].remain <= 0.0)
		CompleteRevive(victim, reviver);
}

// ---------------------------------------------------------------------------
// Người hỗ trợ
// ---------------------------------------------------------------------------
int FindHumanHelper(int victim, int reviver)
{
	for (int c = 1; c <= MaxClients; c++)
	{
		if (c == reviver || c == victim || !IsClientInGame(c) || IsFakeClient(c))
			continue;
		if (!g_bUseHeld[c] || g_iHelping[c])
			continue;
		if (CanHelp(c, victim, reviver, false) && IsLookingAt(c, victim))
			return c;
	}
	return 0;
}

// Trả về bot đủ gần để hỗ trợ ngay; nếu không có, ra lệnh cho một bot đi tới
int HandleBots(int victim, int reviver, float now)
{
	float vPos[3];
	GetClientAbsOrigin(victim, vPos);

	float tankRange = g_cvTankRange.FloatValue;
	float range = g_cvRange.FloatValue;
	float seekRange = g_cvBotSeekRange.FloatValue;

	int nearest = 0;
	float nearestDist = 0.0;

	for (int c = 1; c <= MaxClients; c++)
	{
		if (c == reviver || c == victim || !IsClientInGame(c) || !IsFakeClient(c))
			continue;
		if (g_iHelping[c] || (g_iSeeking[c] && g_iSeeking[c] != victim) || g_fBotCooldown[c] > now)
			continue;
		if (!IsHelperCapable(c, reviver))
			continue;
		if (tankRange > 0.0 && IsTankNearby(c, tankRange))
			continue;

		float pos[3];
		GetClientAbsOrigin(c, pos);
		float dist = GetVectorDistance(pos, vPos);

		if (dist <= range)
		{
			if (g_State[victim].seekBot)
				StopSeek(victim, false);
			return c;
		}

		if (seekRange > 0.0 && dist <= seekRange && (!nearest || dist < nearestDist))
		{
			nearest = c;
			nearestDist = dist;
		}
	}

	int seek = g_State[victim].seekBot;
	if (seek && now > g_State[victim].seekUntil)
	{
		// Đi mãi không tới -> bỏ, tạm cho bot nghỉ
		g_fBotCooldown[seek] = now + 2.0;
		StopSeek(victim, false);
		seek = 0;
	}

	if (!seek && nearest)
	{
		if (L4D2_CommandABot(nearest, 0, BOT_CMD_MOVE, vPos))
		{
			g_State[victim].seekBot = nearest;
			g_State[victim].seekUntil = now + 3.0;
			g_iSeeking[nearest] = victim;
		}
	}
	return 0;
}

void StopSeek(int victim, bool cooldown)
{
	int bot = g_State[victim].seekBot;
	g_State[victim].seekBot = 0;
	if (bot <= 0)
		return;

	g_iSeeking[bot] = 0;
	if (IsClientInGame(bot) && IsFakeClient(bot) && IsPlayerAlive(bot))
		L4D2_CommandABot(bot, 0, BOT_CMD_RESET);
	if (cooldown)
		g_fBotCooldown[bot] = GetGameTime() + 3.0;
}

void StartHelper(int victim, int helper, int reviver, float now)
{
	if (g_State[victim].seekBot == helper)
		StopSeek(victim, false);

	g_State[victim].helper = helper;
	g_State[victim].boosted = true;
	g_State[victim].last = now;
	g_iHelping[helper] = victim;

	UpdateBars(victim, reviver, now);
	StartHelperVisuals(helper, victim, reviver);

	if (g_cvNotify.BoolValue)
	{
		Notify(helper, "Assisting", victim);
		Notify(reviver, "BeingAssisted", helper);
		Notify(victim, "VictimAssisted", reviver, helper);
	}
}

void Notify(int client, const char[] phrase, int a, int b = 0)
{
	if (!IsClientInGame(client) || IsFakeClient(client))
		return;

	if (g_bPhrases && TranslationPhraseExists(phrase))
	{
		if (b > 0)
			PrintHintText(client, "%t", phrase, a, b);
		else
			PrintHintText(client, "%t", phrase, a);
		return;
	}

	// Dự phòng khi thiếu/hỏng file phrase
	if (StrEqual(phrase, "Assisting"))
		PrintHintText(client, "Đang hỗ trợ hồi sinh %N - giữ phím E", a);
	else if (StrEqual(phrase, "BeingAssisted"))
		PrintHintText(client, "%N đang hỗ trợ bạn - hồi sinh nhanh hơn!", a);
	else
		PrintHintText(client, "%N và %N đang cùng hồi sinh bạn", a, b);
}

void StopHelper(int victim, bool updateBars)
{
	int helper = g_State[victim].helper;
	g_State[victim].helper = 0;
	if (helper <= 0)
		return;

	g_iHelping[helper] = 0;
	StopHelperVisuals(helper);
	if (IsClientInGame(helper))
		ClearBar(helper);

	if (updateBars && g_State[victim].active && g_State[victim].boosted)
	{
		int reviver = GetClientOfUserId(g_State[victim].reviver);
		if (IsSurvivor(reviver) && IsDownedSurvivor(victim))
			UpdateBars(victim, reviver, GetGameTime());
	}

	// Chờ lại trước khi bot khác vào thay
	g_State[victim].botJoinAt = GetGameTime() + g_cvBotDelay.FloatValue;
}

// ---------------------------------------------------------------------------
// Hoàn tất / dọn dẹp
// ---------------------------------------------------------------------------
void CompleteRevive(int victim, int reviver)
{
	ClearState(victim);

	// Nếu game đã tự hoàn tất theo thanh tiến trình thì thôi
	if (IsDownedSurvivor(victim))
		L4D_ReviveSurvivor(victim);

	if (IsClientInGame(reviver))
		ClearBar(reviver);
	if (IsClientInGame(victim))
		ClearBar(victim);
}

void ClearState(int victim)
{
	StopHelper(victim, false);
	StopSeek(victim, false);

	int reviver = GetClientOfUserId(g_State[victim].reviver);
	if (reviver > 0)
		UnhookReviver(reviver);

	g_State[victim].Reset();
}

// ---------------------------------------------------------------------------
// Góc nhìn thứ ba + animation cho người hỗ trợ
// ---------------------------------------------------------------------------
void StartHelperVisuals(int helper, int victim, int reviver)
{
	// Quay mặt về phía người bị gục
	float hPos[3], vPos[3], dir[3], ang[3];
	GetClientAbsOrigin(helper, hPos);
	GetClientAbsOrigin(victim, vPos);
	MakeVectorFromPoints(hPos, vPos, dir);
	GetVectorAngles(dir, ang);
	ang[0] = 0.0;
	ang[2] = 0.0;
	g_fHelpYaw[helper] = ang[1];

	if (g_cvAnim.BoolValue)
	{
		TeleportEntity(helper, NULL_VECTOR, ang, NULL_VECTOR);

		if (!g_bHelperHooked[helper])
			g_bHelperHooked[helper] = AnimHookEnable(helper, OnHelperAnim);

		if (!g_bReviverHooked[reviver])
		{
			g_iReviverAct[reviver] = 0;
			g_bReviverHooked[reviver] = AnimHookEnable(reviver, OnReviverAnim);
		}
	}

	// Bot không cần camera
	if (g_cvThirdPerson.BoolValue && g_bHasExtView && !IsFakeClient(helper))
	{
		SetEntPropFloat(helper, Prop_Send, "m_TimeForceExternalView", 99999.3);
		g_bExtView[helper] = true;
	}
}

void StopHelperVisuals(int helper)
{
	if (helper <= 0 || helper > MaxClients)
		return;

	if (g_bExtView[helper])
	{
		g_bExtView[helper] = false;
		if (IsClientInGame(helper))
			SetEntPropFloat(helper, Prop_Send, "m_TimeForceExternalView", 0.0);
	}

	if (g_bHelperHooked[helper])
	{
		g_bHelperHooked[helper] = false;
		if (IsClientInGame(helper))
			AnimHookDisable(helper, OnHelperAnim);
	}
}

void UnhookReviver(int reviver)
{
	if (reviver <= 0 || reviver > MaxClients || !g_bReviverHooked[reviver])
		return;

	g_bReviverHooked[reviver] = false;
	g_iReviverAct[reviver] = 0;
	if (IsClientInGame(reviver))
		AnimHookDisable(reviver, OnReviverAnim);
}

// Chỉ ghi lại, không đổi animation của người cứu chính
Action OnReviverAnim(int client, int &sequence)
{
	if (GetEntPropEnt(client, Prop_Send, "m_reviveTarget") > 0)
		g_iReviverAct[client] = sequence;
	return Plugin_Continue;
}

// Ép người hỗ trợ chạy đúng animation người cứu chính đang chạy
Action OnHelperAnim(int client, int &sequence)
{
	int victim = g_iHelping[client];
	if (victim <= 0)
		return Plugin_Continue;

	int reviver = GetClientOfUserId(g_State[victim].reviver);
	if (reviver > 0 && g_iReviverAct[reviver] > 0)
		sequence = g_iReviverAct[reviver];
	else
		sequence = PickReviveAct(client, victim);
	return Plugin_Changed;
}

// Dự phòng khi chưa ghi được animation của người cứu chính
int PickReviveAct(int helper, int victim)
{
	float h[3], v[3];
	GetClientAbsOrigin(helper, h);
	GetClientAbsOrigin(victim, v);

	bool above  = v[2] > h[2] + 24.0;
	bool crouch = (GetEntityFlags(helper) & FL_DUCKING) != 0;

	if (above)
		return crouch ? L4D2_ACT_TERROR_CROUCH_HEAL_INCAPACITATED_ABOVE : L4D2_ACT_TERROR_HEAL_INCAPACITATED_ABOVE;
	return crouch ? L4D2_ACT_TERROR_CROUCH_HEAL_INCAPACITATED : L4D2_ACT_TERROR_HEAL_INCAPACITATED;
}

// ---------------------------------------------------------------------------
// Thanh tiến trình
// ---------------------------------------------------------------------------
// Đặt lại thanh tiến trình sao cho phần đã làm giữ nguyên
// và thanh đầy đúng lúc hồi sinh xong theo tốc độ hiện tại.
void UpdateBars(int victim, int reviver, float now)
{
	float total = g_State[victim].total;
	if (total <= 0.0)
		return;

	float rate = 1.0 + (g_State[victim].helper > 0 ? g_State[victim].helperRate : 0.0);
	float remain = g_State[victim].remain;
	if (remain < 0.0)
		remain = 0.0;

	float done = 1.0 - remain / total;
	if (done < 0.0) done = 0.0;
	if (done > 0.99) done = 0.99;

	float timeLeft = remain / rate;
	float dur = timeLeft / (1.0 - done);
	float start = now - done * dur;

	SetBar(reviver, start, dur);
	SetBar(victim, start, dur);
	if (g_State[victim].helper > 0)
		SetBar(g_State[victim].helper, start, dur);
}

void SetBar(int client, float start, float dur)
{
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarStartTime", start);
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarDuration", dur);
}

void ClearBar(int client)
{
	// Không xóa thanh nếu người đó đang làm việc khác (cứu người khác, băng bó...)
	if (GetEntPropEnt(client, Prop_Send, "m_reviveTarget") > 0)
		return;
	if (GetEntProp(client, Prop_Send, "m_iCurrentUseAction") != 0)
		return;
	if (IsDownedSurvivor(client) && GetEntPropEnt(client, Prop_Send, "m_reviveOwner") > 0)
		return;

	SetEntPropFloat(client, Prop_Send, "m_flProgressBarStartTime", GetGameTime());
	SetEntPropFloat(client, Prop_Send, "m_flProgressBarDuration", 0.0);
}

// ---------------------------------------------------------------------------
// Kiểm tra điều kiện
// ---------------------------------------------------------------------------
bool CanHelp(int helper, int victim, int reviver, bool keeping)
{
	if (!IsHelperCapable(helper, reviver))
		return false;

	// Người thật phải giữ E; bot thì được plugin giữ E hộ
	if (!IsFakeClient(helper) && !g_bUseHeld[helper])
		return false;

	float hPos[3], vPos[3];
	GetClientAbsOrigin(helper, hPos);
	GetClientAbsOrigin(victim, vPos);

	// Cho dư 25% khi đang hỗ trợ để không bị ngắt vì xê dịch nhẹ
	float range = g_cvRange.FloatValue * (keeping ? 1.25 : 1.0);
	return GetVectorDistance(hPos, vPos) <= range;
}

bool IsHelperCapable(int client, int reviver)
{
	if (client == reviver || !IsSurvivor(client) || !IsPlayerAlive(client))
		return false;
	if (IsDownedSurvivor(client) || IsPinned(client))
		return false;
	// Đang tự cứu người khác
	if (GetEntPropEnt(client, Prop_Send, "m_reviveTarget") > 0)
		return false;
	// Đang băng bó, đổ xăng, dùng defib...
	if (!g_iHelping[client] && GetEntProp(client, Prop_Send, "m_iCurrentUseAction") != 0)
		return false;
	return true;
}

bool IsLookingAt(int client, int target)
{
	float eye[3], ang[3], fwd[3], tPos[3], dir[3];
	GetClientEyePosition(client, eye);
	GetClientEyeAngles(client, ang);
	GetAngleVectors(ang, fwd, NULL_VECTOR, NULL_VECTOR);

	GetClientAbsOrigin(target, tPos);
	tPos[2] += 16.0;   // người bị gục nằm sát đất

	MakeVectorFromPoints(eye, tPos, dir);
	NormalizeVector(dir, dir);
	return GetVectorDotProduct(fwd, dir) >= 0.5;   // trong khoảng ~60°
}

bool IsTankNearby(int client, float range)
{
	float pos[3], tPos[3];
	GetClientAbsOrigin(client, pos);

	for (int i = 1; i <= MaxClients; i++)
	{
		if (!IsClientInGame(i) || GetClientTeam(i) != TEAM_INFECTED || !IsPlayerAlive(i))
			continue;
		if (GetEntProp(i, Prop_Send, "m_zombieClass") != ZC_TANK)
			continue;
		if (GetEntProp(i, Prop_Send, "m_isIncapacitated"))   // Tank đang chết
			continue;

		GetClientAbsOrigin(i, tPos);
		if (GetVectorDistance(pos, tPos) <= range)
			return true;
	}
	return false;
}

bool IsPinned(int client)
{
	static const char props[][] =
	{
		"m_tongueOwner", "m_pounceAttacker", "m_jockeyAttacker", "m_pummelAttacker", "m_carryAttacker"
	};
	for (int i = 0; i < sizeof(props); i++)
	{
		if (GetEntPropEnt(client, Prop_Send, props[i]) > 0)
			return true;
	}
	return false;
}

bool IsSurvivor(int client)
{
	return client > 0 && client <= MaxClients && IsClientInGame(client) && GetClientTeam(client) == TEAM_SURVIVOR;
}

bool IsDownedSurvivor(int client)
{
	if (!IsSurvivor(client) || !IsPlayerAlive(client))
		return false;
	return GetEntProp(client, Prop_Send, "m_isIncapacitated") != 0
		|| GetEntProp(client, Prop_Send, "m_isHangingFromLedge") != 0;
}
